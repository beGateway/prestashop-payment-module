<?php
namespace BeGateway;

class VoidOperation extends ChildTransaction {
}
?>
