<?php
namespace BeGateway\PaymentMethod;

class Emexvoucher extends Base {
}
?>
